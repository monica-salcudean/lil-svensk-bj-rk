# lil svensk björn 🐻

App para aprender sueco (A1–C2) con Björn, el oso polar. Vocabulario por temas, frases del día a día, gramática (pronombres, en/ett, orden de palabras, *inte*, preposiciones, verbos), traducción, reading y writing estilo Cambridge. Funciona sin internet, guarda el progreso en el navegador y es instalable como app.

---

## 📂 Qué hay en esta carpeta

| Archivo | Para qué |
|---|---|
| `index.html` | La app entera (un solo archivo). |
| `manifest.json` | Hace que se pueda instalar como app. |
| `icon.svg`, `icon-192.png`, `icon-512.png` | El icono del oso. |
| `.nojekyll` | Le dice a GitHub Pages que sirva los archivos tal cual. |

> Para uso local no necesitas nada más: abre `index.html` con doble clic.

---

## 🌐 Subirla a GitHub Pages (gratis, sin marca de agua)

1. Entra en **https://github.com** e inicia sesión (o créate una cuenta).
2. Arriba a la derecha, **+ › New repository**.
   - **Repository name:** `svensk-bjorn` (o el que quieras)
   - Marca **Public** → **Create repository**.
3. En la página del repo vacío pulsa **uploading an existing file** (o **Add file › Upload files**).
4. **Arrastra todos los archivos de esta carpeta** (index.html, manifest.json, los 3 iconos y .nojekyll) a la ventana.
   - Si no ves el `.nojekyll`, actívalo en tu sistema con "mostrar archivos ocultos", o créalo luego con **Add file › Create new file** y nómbralo `.nojekyll`.
5. Abajo pulsa **Commit changes**.
6. Ve a **Settings** (pestaña del repo) › en el menú izquierdo **Pages**.
7. En **Branch** elige **main** y carpeta **/ (root)** → **Save**.
8. Espera ~1 minuto y recarga. Arriba aparecerá:
   **"Your site is live at `https://TU-USUARIO.github.io/svensk-bjorn/`"**

¡Esa es tu URL! Funciona en cualquier móvil u ordenador.

---

## 📲 Instalarla como app

**iPhone (Safari):** abre la URL › botón **Compartir** › **Añadir a pantalla de inicio**. Se abre a pantalla completa con el icono del oso.

**Android (Chrome):** abre la URL › menú **⋮** › **Instalar aplicación** / **Añadir a pantalla de inicio**.

**Ordenador (Chrome/Edge):** abre la URL › icono **Instalar** en la barra de direcciones (o menú ⋮ › Instalar). Se abre en su propia ventana, sin barra del navegador.

---

## 🏷️ Pegatina NFC (abrir con un toque)

1. Compra pegatinas NFC (NTAG213 o similar, muy baratas).
2. Instala una app como **NFC Tools** (iOS/Android).
3. **Write › Add a record › URL/URI** › pega tu URL de GitHub Pages › **Write**.
4. Acerca el móvil a la pegatina y se abre la app. Si la instalaste en la pantalla de inicio, se abre esa.

---

## 💾 Notas

- El progreso se guarda **por navegador y por dispositivo**. Cada persona que use la app en su móvil tiene su propio progreso, independiente.
- Dentro de la app hay **perfiles** (icono del oso arriba a la derecha) por si varios comparten un mismo dispositivo.
- En **Framsteg** puedes **Exportar/Importar** tu progreso (archivo .json) para pasarlo de un dispositivo a otro o hacer copia.
- Elige tu nivel (A1–C2) en **Lär › Ordförråd**: baja el nivel si quieres algo más fácil, súbelo si se te queda corto.

Hej då! 🐻🇸🇪
